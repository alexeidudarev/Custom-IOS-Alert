//
//  ADModalStatus.h
//  ADModalStatus
//
//  Created by Alexei Dudarev on 23/06/2018.
//  Copyright © 2018 Alexei Dudarev. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ADModalStatus.
FOUNDATION_EXPORT double ADModalStatusVersionNumber;

//! Project version string for ADModalStatus.
FOUNDATION_EXPORT const unsigned char ADModalStatusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ADModalStatus/PublicHeader.h>


